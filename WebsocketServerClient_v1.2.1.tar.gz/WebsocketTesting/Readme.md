Setup to test/play around with websocket traffic.

* `backendServer` is the golang based code for deploying an echo server. It replies back websocket messages that are sent to it.
* `client` contains the code for sending websocket messages and receiving any replies. It assumes that a reply is received for any messages that it sends.
* `certs` contains setup for dummy certificates for setting up end to end TLS connectivity across Application Gateway.
* `setup` has bicep scripts for setting up Azure resources.

# Run websocket client server locally.
```bash
cd certs
bash certSetup.sh
```

```bash
cd backendServer
go run server.go -cert ../certs/completeServer.pem -key ../certs/leaf.key
```
```bash
cd client
go run client.go -remoteUrl=ws://127.0.0.1:8080/ -maxConnections=1000 -duration=900 -maxNewConnectionsPerSecond=200 -pauseBetweenMessages=12
go run client.go -remoteUrl=wss://127.0.0.1:8443/ -maxConnections=1000 -duration=900 -maxNewConnectionsPerSecond=200 -pauseBetweenMessages=12
```

# Performance test over Application Gateway Dv2 sku.
* Create ssh keys for yourself, if you don't have one, using internet documentation around `ssh-keygen`. These would be used for easily connecting to client and backend vms.
* The `main.bicep` deploys an Application Gateway with two instances, client VM and backend VM. `client` and `backendServer` will be copied over to client and backend vm respectively for execution and monitored from the respective instances. `certs` should be copied over to backend vm as well.
  * Sets up Application Gateway listening on 10.0.1.20 on port 80 for HTTP and 443 for end to end TLS.
* Deploy all resources with
```bash
az account set --subscription 1496a758-b2ff-43ef-b738-8e9eb5161a86  # use centraluseuap slice for deployments.
scenario=<>; az group create --name $scenario --location centraluseuap; az deployment group create --name $scenario --resource-group $scenario --template-file ./main.bicep --parameters publicKey=@~/.ssh/id_rsa.pub sslCertData=@../certs/leaf.pfx trustedRootCertData=@../certs/rootCA.pem  vmSetupString=@./vmSetup.sh scenarioPrefix=$scenario onlyAppGw=false
# Update parameters above to create your own specific setup.
```
* Identify ips for client and backend vm from Azure Portal or az-cli.
* Use rsync or scp to copy over the folders:
```bash
rsync -av certs appgwtester@<ip>:~/
```
* Start server on backend vm with
```bash
go run server.go -cert ../certs/completeServer.pem -key ../certs/leaf.key
```
* Start client on client vm with
```bash
go run client.go -remoteUrl=wss://10.0.1.20/ -maxConnections=12000 -duration=600 -maxNewConnectionsPerSecond=200 -pauseBetweenMessages=30 -messageSizes=50
# This induces a system memory utilization of 50% with nginx memory at 25% on Application Gateway.


```
