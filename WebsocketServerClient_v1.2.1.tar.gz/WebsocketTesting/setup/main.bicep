param publicKey string
param location string = resourceGroup().location
param scenarioPrefix string = 'mine'
param sslCertData string
param trustedRootCertData string
param vmSetupString string
param onlyAppGw bool = true

resource nsg 'Microsoft.Network/networkSecurityGroups@2021-02-01' = if (!onlyAppGw) {
  name: '${scenarioPrefix}NSG'
  location: location
  properties: {
    securityRules: [
      {
        name: 'AllowGatewayManager'
        properties: {
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '65200-65535'
          sourceAddressPrefix: 'GatewayManager'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 102
          direction: 'Inbound'
        }
      }
    ]
  }
}

resource vnet 'Microsoft.Network/virtualNetworks@2023-09-01' = if (!onlyAppGw) {
  name: '${scenarioPrefix}Vnet'
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [
        '10.0.0.0/16'
      ]
    }
    subnets: [
      {
        name: '${scenarioPrefix}AppGw'
        properties: {
          addressPrefix: '10.0.1.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
      {
        name: '${scenarioPrefix}Client'
        properties: {
          addressPrefix: '10.0.2.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
      {
        name: '${scenarioPrefix}Server'
        properties: {
          addressPrefix: '10.0.3.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
    ]
  }
}

resource vnetExisting 'Microsoft.Network/virtualNetworks@2023-09-01' existing = if (onlyAppGw) {
  name: '${scenarioPrefix}Vnet'
}

var vnetResource = onlyAppGw ? vnetExisting : vnet

module gw './appgw.bicep' = {
  name: '${scenarioPrefix}AppGw'
  params: {
    location: location
    subnetId: vnetResource.properties.subnets[0].id
    gatewayName: '${scenarioPrefix}AppGw'
    sslCertData: sslCertData
    sslCertPassword: 'test'
    trustedRootCertData: trustedRootCertData
  }
}

resource gateway 'Microsoft.Network/applicationGateways@2023-09-01' existing = {
    name: '${scenarioPrefix}AppGw'
}

module client './vm.bicep' = if (!onlyAppGw) {
  name: '${scenarioPrefix}Client'
  params: {
    vmName: '${scenarioPrefix}Client'
    vmAdminUsername: 'appgwtester'
    publicKey: publicKey
    location: location
    subnetId: vnet.properties.subnets[1].id
    vmSetupString: vmSetupString
    nsgId: nsg.id
    backendPoolId: ''
  }
}

module server './vm.bicep' = if (!onlyAppGw) {
  name: '${scenarioPrefix}Server'
  params: {
    vmName: '${scenarioPrefix}Server'
    vmAdminUsername: 'appgwtester'
    publicKey: publicKey
    location: location
    subnetId: vnet.properties.subnets[2].id
    vmSetupString: vmSetupString
    nsgId: nsg.id
    backendPoolId: gateway.properties.backendAddressPools[0].id
  }
}
