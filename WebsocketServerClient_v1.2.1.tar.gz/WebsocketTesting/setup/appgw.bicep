param location string
param gatewayName string
param subnetId string
param sslCertData string
@secure()
param sslCertPassword string
param trustedRootCertData string

var appgwId = resourceId('Microsoft.Network/applicationGateways', gatewayName)

resource publicIP 'Microsoft.Network/publicIPAddresses@2021-02-01' = {
  name: '${gatewayName}-public'
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

resource gateway 'Microsoft.Network/applicationGateways@2023-09-01' = {
  name: gatewayName
  location: location
  properties: {
    sku: {
      name: 'Standard_v2'
      tier: 'Standard_v2'
      capacity: 2
    }
    gatewayIPConfigurations: [
      {
        name: 'appGatewayIpConfig'
        properties: {
          subnet: {
            id: subnetId
          }
        }
      }
    ]
    frontendIPConfigurations: [
      {
        name: 'appGatewayFrontendIP'
        properties: {
          privateIPAllocationMethod: 'Static'
          privateIPAddress: '10.0.1.20'
          subnet: {
            id: subnetId
          }
        }
      }
      {
        name: 'appGatewayFrontendPublic'
        properties: {
          publicIPAddress: {
            id: publicIP.id
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: 'httpPort'
        properties: {
          port: 80
        }
      }
      {
        name: 'httpsPort'
        properties: {
          port: 443
        }
      }
    ]
    sslCertificates: [
      {
        name: 'appGatewaySslCert'
        properties: {
          password: sslCertPassword
          data: sslCertData
        }
      }
    ]
    trustedRootCertificates: [
      {
        name: 'appGatewayTrustedRootCert'
        properties: {
          data: base64(trustedRootCertData)
        }
      }
    ]
    backendAddressPools: [
      {
        name: 'appGatewayBackendPool'
        properties: {
        }
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'appGatewayBackendHttpSettings'
        properties: {
          port: 8080
          protocol: 'Http'
          cookieBasedAffinity: 'Disabled'
          hostName: 'test'
          requestTimeout: 84000
          probe: {
            id: '${appgwId}/probes/httpProbe'
          }
        }
      }
      {
        name: 'appGatewayBackendHttpsSettings'
        properties: {
          port: 8443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          hostName: 'test'
          requestTimeout: 84000
          trustedRootCertificates: [
            {
              id: '${appgwId}/trustedRootCertificates/appGatewayTrustedRootCert'
            }
          ]
          probe: {
            id: '${appgwId}/probes/httpsProbe'
          }
        }
      }
    ]
    httpListeners: [
      {
        name: 'appGatewayHttpListener'
        properties: {
          protocol: 'Http'
          frontendIPConfiguration: {
            id: '${appgwId}/frontendIPConfigurations/appGatewayFrontendIP'
          }
          frontendPort: {
            id: '${appgwId}/frontendPorts/httpPort'
          }
        }
      }
      {
        name: 'appGatewayHttpsListener'
        properties: {
          protocol: 'Https'
          sslCertificate: {
            id: '${appgwId}/sslCertificates/appGatewaySslCert'
          }
          frontendIPConfiguration: {
            id: '${appgwId}/frontendIPConfigurations/appGatewayFrontendIP'
          }
          frontendPort: {
            id: '${appgwId}/frontendPorts/httpsPort'
          }
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'rule1'
        properties: {
          ruleType: 'Basic'
          priority: 1000
          httpListener: {
            id: '${appgwId}/httpListeners/appGatewayHttpListener'
          }
          backendAddressPool: {
            id: '${appgwId}/backendAddressPools/appGatewayBackendPool'
          }
          backendHttpSettings: {
            id: '${appgwId}/backendHttpSettingsCollection/appGatewayBackendHttpSettings'
          }
        }
      }
      {
        name: 'rule2'
        properties: {
          ruleType: 'Basic'
          priority: 1001
          httpListener: {
            id: '${appgwId}/httpListeners/appGatewayHttpsListener'
          }
          backendAddressPool: {
            id: '${appgwId}/backendAddressPools/appGatewayBackendPool'
          }
          backendHttpSettings: {
            id: '${appgwId}/backendHttpSettingsCollection/appGatewayBackendHttpsSettings'
          }
        }
      }
    ]
    probes: [
      {
        name: 'httpProbe'
        properties: {
          protocol: 'Http'
          pickHostNameFromBackendHttpSettings: true
          path: '/'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
        }
      }
      {
        name: 'httpsProbe'
        properties: {
          protocol: 'Https'
          pickHostNameFromBackendHttpSettings: true
          path: '/'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
        }
      }
    ]
  }
}
