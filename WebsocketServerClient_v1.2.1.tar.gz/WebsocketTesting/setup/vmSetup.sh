
sudo sysctl -w net.ipv4.ip_local_port_range="10000 63000"
sudo sysctl -w net.core.rmem_max=33554432
sudo sysctl -w net.core.wmem_max=33554432
sudo sysctl -w net.ipv4.tcp_max_syn_backlog=16384
sudo sysctl -w net.ipv4.tcp_synack_retries=1
sudo sysctl -w net.ipv4.tcp_max_orphans=40000
sudo sysctl -w net.nf_conntrack_max=256000
sudo sysctl -w fs.suid_dumpable=2
sudo sysctl -w net.netfilter.nf_conntrack_tcp_timeout_established=1800
sudo sysctl -w net.core.rmem_default=20971520


cat >> /etc/security/limits.conf <<EOF
* hard nofile 100000
* soft nofile 100000
EOF

sudo apt-get update -y
sudo apt-get install -y golang
