set -x
set -e

# Setting up dummy certificates for deployment.

openssl genrsa -out rootCA.key 4096
openssl req -x509 -new -nodes -key rootCA.key -sha256 -days 1024 -out rootCA.pem --subj "/CN=DummyRoot"
openssl genrsa -out leaf.key 4096
openssl req -new -key leaf.key -out leaf.csr --subj "/CN=DummyLeaf"
openssl x509 -req -in leaf.csr -CA rootCA.pem -CAkey rootCA.key -CAcreateserial -out leaf.crt -days 500 -sha256
openssl pkcs12 -export -out leaf.pfx -inkey leaf.key -in leaf.crt -certfile rootCA.pem -password pass:test
cat leaf.crt rootCA.pem > completeServer.pem
