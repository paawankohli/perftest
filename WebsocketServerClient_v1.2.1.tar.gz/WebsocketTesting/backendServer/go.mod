module backend

go 1.18

require github.com/gobwas/ws v1.3.2