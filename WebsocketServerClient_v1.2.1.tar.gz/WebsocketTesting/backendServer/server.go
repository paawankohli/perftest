package main

/*
Setup an http and https server for websockets. The intent is to then send traffic to any port and get a relevant response back.
Sample command:
go run server.go -cert ../certs/completeServer.pem -key ../certs/leaf.key
*/

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gobwas/ws"
	"github.com/gobwas/ws/wsutil"
)

func serverHandler(w http.ResponseWriter, r *http.Request) {

	// Handle HTTP probes at root path itself.
	if r.URL.Path == "/" && r.Header.Get("Upgrade") == "" {
		log.Println("Received probe at ", time.Now())
		w.WriteHeader(http.StatusOK)
		return
	}

	// Setup the upgrade to websocket.
	conn, _, _, err := ws.UpgradeHTTP(r, w)
	if err != nil {
		log.Println("Couldn't handle incoming connection.")
		return
	}

	go func() {
		defer conn.Close()

		for {

			// Listen for a message from the client
			msg, err := wsutil.ReadClientText(conn)
			if err != nil {
				log.Println("Error in receiving. ", err)
				return
			}

			if err := wsutil.WriteServerText(conn, msg); err != nil {
				log.Println("Error in sending. ", err)
				return
			}
		}
	}()
}

func main() {
	var (
		certFile string
		keyFile  string
	)

	flag.StringVar(&certFile, "cert", "server.crt", "path to the server certificate")
	flag.StringVar(&keyFile, "key", "server.key", "path to the server key")
	flag.Parse()

	log.Println("Starting...")
	mux := http.NewServeMux()
	mux.HandleFunc("/", serverHandler)

	// Setup websocket server over http and https.
	httpServer := &http.Server{
		Addr:    ":8080",
		Handler: mux,
	}

	// httpsServer := &http.Server{
	// 	Addr:    ":8443",
	// 	Handler: mux,
	// }

	wg := &sync.WaitGroup{}
	wg.Add(1)

	go func() {
		defer wg.Done()
		if err := httpServer.ListenAndServe(); err != nil {
			fmt.Println("Error starting http server: ", err)
		}
	}()

	// wg.Add(1)
	// go func() {
	// 	defer wg.Done()
	// 	if err := httpsServer.ListenAndServeTLS(certFile, keyFile); err != nil {
	// 		fmt.Println("Error starting https server: ", err)
	// 	}
	// }()

	wg.Wait()
}
