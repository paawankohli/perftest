module appgwwebsocket.com/m/v2

go 1.18

require golang.org/x/net v0.25.0
