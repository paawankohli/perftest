package main

/*
Simple websocket client. It sends messages and then waits for a response back. Make inline changes to change flows.
To setup:
 1. Install golang.
 2. Run "go get -d" in this folder.
 3. Run "go run client.go -h" to see various options.
 4. Sample command for websocket over http: go run client.go -remoteUrl=ws://127.0.0.1:8080/ -maxConnections=200 -duration=900 -maxNewConnectionsPerSecond=50 -pauseBetweenMessages=10
 5. Sample command for websocket over https: go run client.go -remoteUrl=ws://127.0.0.1:8443/ -maxConnections=200 -duration=900 -maxNewConnectionsPerSecond=50 -pauseBetweenMessages=10
*/

import (
	"flag"
	"golang.org/x/net/websocket"
	"log"
	"time"
	"math/rand"
	"strings"
	"strconv"
	"crypto/tls"
)

// Generating data before hand and reusing it helps keep the client's memory footprint low.
var globalData []string;
func generateData(messageSizes string) {
	sizes := strings.Split(messageSizes, ",")
	for i := 0; i < len(sizes); i++ {
		val, err := strconv.ParseFloat(sizes[i], 64)
		if err != nil {
			log.Fatal(err)
		}
		globalData = append(globalData, strings.Repeat("a", int(val * 1000)))
	}
}

var connsCreated = 0

// Client code that sets up a websocket connection, honoring the maxNewConnectionsPerSecond constraint and then sends/received message with gaps of pauseBetweenMessages seconds.
func client(newConnectionRateLimiter <-chan time.Time, remoteUrl *string, pauseBetweenMessages int) {
	// Wait for tick to control number of new connections per second
	<-newConnectionRateLimiter
	inFlightNewConnectionLimiter <- true
	// log.Println("Creating new connection")

	wsConfig, err := websocket.NewConfig(*remoteUrl, "http://localhost")
	if err != nil {
		log.Println("Error in establishing new connection. Retrying after a bit...", err)
		// Release the in-flight slot before retrying, else it leaks and the limiter deadlocks.
		<-inFlightNewConnectionLimiter
		time.Sleep(time.Duration(int(time.Second) * pauseBetweenMessages))
		go client(newConnectionRateLimiter, remoteUrl, pauseBetweenMessages)
		return
	}

	// Hack since we are working with test data.
	wsConfig.TlsConfig = &tls.Config{InsecureSkipVerify: true}

	// Dial up a new connection and upgrade it to websocket.
	ws, err := websocket.DialConfig(wsConfig)
	if err != nil {
		log.Println("Error in establishing new connection. Retrying after a bit...", err)
		// Release the in-flight slot before retrying, else it leaks and the limiter deadlocks.
		<-inFlightNewConnectionLimiter
		time.Sleep(time.Duration(int(time.Second) * pauseBetweenMessages))
		go client(newConnectionRateLimiter, remoteUrl, pauseBetweenMessages)
		return

	}

	// Something to indicate progress. Having too much logging makes it difficult to parse through logs.
	connsCreated ++
	if connsCreated % 100 == 0 {
		log.Println(connsCreated, " number of new connections have been created.")
	}

	defer ws.Close()
	<- inFlightNewConnectionLimiter
	var response = make([]byte, 200*1024+10)

	// In a loop, start the send/receive process. If anything errors out, start a connection/client to maintain the expected number of maxConnections.
	for {
		// log.Println("Sending", data)
		if startClosing {
			return
		}

		// Send message.
		data := globalData[rand.Intn(len(globalData))]
		// log.Println(data)
		if err := websocket.Message.Send(ws, data); err != nil {
			log.Println("Error in sending. ", err)
			go client(newConnectionRateLimiter, remoteUrl, pauseBetweenMessages)
			return
		}

		// Early exit if program is expected to shutdown.
		if startClosing {
			return
		}

		// Receive same message back.
		if err := websocket.Message.Receive(ws, &response); err != nil {
			log.Println("Error in receiving. ", err)
			go client(newConnectionRateLimiter, remoteUrl, pauseBetweenMessages)
			return
		}

		// A basic sanity check to ensure that we are getting back what we sent.
		if data != string(response) {
			log.Println("Error: we aren't receiving the right data back.")
		}

		if startClosing {
			return
		}

		// Disabled code for churning the connections at reasonable rate.
		if *maxConnections <= connsCreated + 5 && 1 == 2 {
			// Almost all the initial users have been created. We should start churning some of the existing connections, based on a probability that doesn't overwhelms the new connection rate.
			if rand.Intn(*maxConnections) < *maxNewConnectionsPerSecond * pauseBetweenMessages {
				go client(newConnectionRateLimiter, remoteUrl, pauseBetweenMessages)
				return
			}
		}

		time.Sleep(time.Duration(int(time.Second) * (pauseBetweenMessages)))
	}
}

var startClosing = false
var inFlightNewConnectionLimiter chan bool;
var maxConnections *int;
var maxNewConnectionsPerSecond *int;

func main() {
	remoteUrl := flag.String("remoteUrl", "ws://127.0.0.1:8080", "Remote address to target.")
	maxConnections = flag.Int("maxConnections", 1, "Number of parallel connections/users at a time.")
	duration := flag.Int("duration", 5, "Number of seconds each connection should last.")
	pauseBetweenMessages := flag.Int("pauseBetweenMessages", 10, "Number of seconds to pause between successive messages on the same connection.")
	maxNewConnectionsPerSecond = flag.Int("maxNewConnectionsPerSecond", 10, "Number of new connections created per second.")
	messageSizes := flag.String("messageSizes", "0.1,0.1,0.2,0.4,1,1,1,10", "Comma-separated message lengths in kB.")
	flag.Parse()

	// Generate data that would be sent to the server.
	generateData(*messageSizes)

	// Ensure that only maxNewConnectionsPerSecond are sent out.
	newConnectionRateLimiter := time.Tick(1000 *time.Millisecond / (time.Duration)(*maxNewConnectionsPerSecond))
	// Ensure that only maxNewConnectionsPerSecond are in flight at any point. If server is overwhelmed, there is no need to hammer it more.
	inFlightNewConnectionLimiter = make(chan bool, *maxNewConnectionsPerSecond)

	log.Println("Starting...", *maxConnections)
	// Startup maxConnections number worth connections/users. The clients would become active/operational while ensuring that maxNewConnectionsPerSecond constraint isn't violated.
	for conn := 0; conn < (*maxConnections); conn++ {
		go client(newConnectionRateLimiter, remoteUrl, *pauseBetweenMessages)
	}

	// Gracefully close the existing connections.
	time.Sleep(time.Duration(int(time.Second) * (*duration)))
	startClosing = true
	time.Sleep(time.Duration(int(time.Second) * 2 * (*pauseBetweenMessages)))
	log.Println("Exiting...")
}
